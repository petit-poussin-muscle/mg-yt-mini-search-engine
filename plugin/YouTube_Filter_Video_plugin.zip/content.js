// content.js — YouTube Members Filter (All / Non-members / Members-only)
// Works on Chrome & Firefox (MV3 content script only)

/* global browser, chrome */
window.chrome = window.chrome || window.browser;

// ---- Tunables (no regex) -----------------------------------------------
const CLASS_TOKENS = [
  "badge-style-type-members-only",
  "members-only",
  "member-badge",
  "membership"
];

const ATTR_TOKENS = [
  "members", "member",     // en
  "メンバー",               // ja
  "會員", "会员",           // zh
  "membres", "membre",     // fr
  "miembros", "miembro",   // es
  "mitglieder",            // de
  "abbonati",              // it
  "membros", "membro"      // pt
].map(s => s.toLowerCase());

// --- Allowlist URL patterns ---------------------------------------------
// Only run on channel Videos pages. Add more patterns if you like.
//
// Exact matches (rarely needed):
const ALLOW_EXACT = [
  // "https://www.youtube.com/@MyChannel/videos"
];

// Glob-style patterns (easy): * matches any characters (no slashes limit)
const ALLOW_GLOBS = [
  "https://www.youtube.com/@*/videos",
  "https://www.youtube.com/@*/shorts",
  "https://www.youtube.com/@*/streams"
];

// Turn the globs into RegExps (safe-escaped)
function globToRegExp(glob) {
  const esc = s => s.replace(/[-/\\^$+?.()|[\]{}]/g, "\\$&");
  const re = "^" + glob.split("*").map(esc).join(".*") + "$";
  return new RegExp(re);
}
const ALLOW_REGEX = ALLOW_GLOBS.map(globToRegExp);

function isAllowedUrl(href = location.href) {
  if (ALLOW_EXACT.includes(href)) return true;
  if (ALLOW_REGEX.some(r => r.test(href))) return true;
  return false;
}

// Applicability: we only activate on allowed URLs AND when the grid exists
function isApplicablePage() {
  if (!isAllowedUrl()) return false;
  return !!document.querySelector("#contents ytd-rich-item-renderer");
}

// ---- Constants & state --------------------------------------------------
const STORAGE_KEY   = "mode";            // "all" | "non" | "members"
const UI_ID         = "yt-members-filter-ui";
const STYLE_ID      = "yt-members-filter-style";
const COLLAPSED_KEY = "uiCollapsed";

let mode = "members";
let mo;
let scheduled = false;
let debugOn = false;
let collapsed = false;

// ---- Bootstrap ----------------------------------------------------------
chrome.storage?.local?.get?.({ [STORAGE_KEY]: mode, [COLLAPSED_KEY]: false }, (res) => {
  if (res && typeof res[STORAGE_KEY] === "string") mode = res[STORAGE_KEY];
  collapsed = !!res?.[COLLAPSED_KEY];
  injectStyle();
  ensureUI();
  filterAll();     // fera automatiquement show/hide selon la route
  startObserver(); // suit les navigations SPA & l’infinite scroll
});

// ---- UI (radio group, repliable) ---------------------------------------
function ensureUI() {
  if (document.getElementById(UI_ID)) return;

  const wrap = document.createElement("div");
  wrap.id = UI_ID;
  Object.assign(wrap.style, {
    position: "fixed", zIndex: 999999, top: "0px", right: "220px",
    background: "rgba(32,32,32,.9)", color: "#fff",
    padding: "8px 12px", borderRadius: "10px",
    font: "13px/1.3 system-ui,-apple-system,Segoe UI,Roboto,Arial",
    boxShadow: "0 2px 12px rgba(0,0,0,.3)", userSelect: "none"
  });

  const title = document.createElement("div");
  title.style.marginBottom = "6px";
  title.style.fontWeight = "600";
  title.style.cursor = "pointer";
  const setTitleText = () => {
    title.textContent = collapsed ? "▲ YouTube Filter Video" : "▼ YouTube Filter Video";
  };
  setTitleText();

  const form = document.createElement("div");
  form.style.display = collapsed ? "none" : "grid";
  form.style.gap = "4px";

  // Click: collapse/expand ; Shift+Click: debug outlines
  title.addEventListener("click", (e) => {
    if (e.shiftKey) {
      debugOn = !debugOn;
      document.documentElement.classList.toggle("__members_debug", debugOn);
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    collapsed = !collapsed;
    form.style.display = collapsed ? "none" : "grid";
    setTitleText();
    chrome.storage?.local?.set?.({ [COLLAPSED_KEY]: collapsed });
  });

  addRadio(form, "all", "All");
  addRadio(form, "non", "Non-members");
  addRadio(form, "members", "Members-only");

  wrap.append(title, form);
  document.documentElement.appendChild(wrap);

  // Dès la création, calque la visibilité sur l’applicabilité courante
  wrap.style.display = isApplicablePage() ? "" : "none";
}

function addRadio(container, value, labelText) {
  const id = `members-filter-${value}`;
  const label = document.createElement("label");
  label.setAttribute("for", id);
  Object.assign(label.style, {
    display: "flex", alignItems: "center", gap: "6px", cursor: "pointer"
  });

  const rb = document.createElement("input");
  rb.type = "radio";
  rb.name = "members-filter-mode";
  rb.id = id;
  rb.value = value;
  rb.checked = (mode === value);
  rb.addEventListener("change", () => setMode(value));

  const text = document.createElement("span");
  text.textContent = labelText;

  label.append(rb, text);
  container.appendChild(label);
}

function setMode(v) {
  mode = v;
  chrome.storage?.local?.set?.({ [STORAGE_KEY]: mode });
  filterAll();
  logStats("mode-change");
}

// ---- Styling / debug CSS ------------------------------------------------
function injectStyle() {
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = `
    html.__members_debug #contents ytd-rich-item-renderer {
      outline: 1px solid rgba(255,0,0,.35); outline-offset: -2px;
    }
    html.__members_debug #contents ytd-rich-item-renderer[data-is-member="1"] {
      outline: 2px solid rgba(0,200,0,.9);
    }
  `;
  document.documentElement.appendChild(style);
}

// ---- Selection / filtering ---------------------------------------------
const qAll   = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const tilesQ = "#contents ytd-rich-item-renderer";
const getTiles = (root = document) => qAll(tilesQ, root);

function showUI(show) {
  const ui = document.getElementById(UI_ID);
  if (ui) ui.style.display = show ? "" : "none";
}

function resetTiles() {
  const tiles = getTiles();
  for (const t of tiles) {
    t.removeAttribute("data-is-member");
    t.style.display = "";
  }
}

function filterAll() {
  // Si la route n'est pas applicable (SPA, page watch, Shorts, exclue, etc.)
  if (!isApplicablePage()) {
    resetTiles();
    showUI(false);
    return;
  }
  showUI(true);

  const tiles = getTiles();

  // 1) (Re)classify every tile
  for (const t of tiles) {
    const isMember = tileIsMember(t);
    if (isMember) t.setAttribute("data-is-member", "1");
    else t.removeAttribute("data-is-member");
  }

  // 2) Apply chosen visibility mode
  for (const t of tiles) {
    const isM = t.getAttribute("data-is-member") === "1";
    switch (mode) {
      case "all":     t.style.display = "";            break;
      case "non":     t.style.display = isM ? "none" : ""; break;
      case "members": t.style.display = isM ? "" : "none"; break;
    }
  }
}

// ---- Membership detector (no regex on words) ---------------------------
function tileIsMember(tile) {
  const specialOverlay = tile.querySelector(
    'ytd-thumbnail-overlay-time-status-renderer[overlay-style]:not([overlay-style="DEFAULT"])'
  );
  if (specialOverlay) return true;

  const badges = tile.querySelectorAll('ytd-badge-supported-renderer');
  for (const b of badges) {
    for (const cls of b.classList) {
      const c = cls.toLowerCase();
      if (CLASS_TOKENS.some(tok => c.includes(tok))) return true;
    }
    for (const attr of b.attributes) {
      const v = (attr.value || "").toLowerCase();
      if (v && ATTR_TOKENS.some(tok => v.includes(tok))) return true;
    }
    const labelled = b.querySelector('[aria-label], [title]');
    if (labelled) {
      const lab = (labelled.getAttribute('aria-label') || labelled.getAttribute('title') || "").toLowerCase();
      if (lab && ATTR_TOKENS.some(tok => lab.includes(tok))) return true;
    }
  }

  const texts = qAll('#overlays .badge-shape-wiz__text', tile).map(n => (n.textContent || "").trim()).filter(Boolean);
  for (const txt of texts) {
    if (!looksLikeDuration(txt)) return true;
  }

  const visibleMetaBadge = tile.querySelector('#meta ytd-badge-supported-renderer:not([hidden])');
  if (visibleMetaBadge) {
    const label = (visibleMetaBadge.getAttribute('aria-label') || visibleMetaBadge.getAttribute('title') || visibleMetaBadge.textContent || "").trim();
    if (label) return true;
  }

  return false;
}

function looksLikeDuration(s) {
  const parts = s.split(":");
  if (parts.length === 2 || parts.length === 3) {
    return parts.every(p => /^\d+$/.test(p));
  }
  return false;
}

// ---- Observe SPA & infinite scroll -------------------------------------
function startObserver() {
  if (mo) mo.disconnect();
  mo = new MutationObserver(() => schedule(filterAll));
  mo.observe(document.documentElement, { childList: true, subtree: true });

  // YouTube SPA events
  window.addEventListener("yt-navigate-start", () => filterAll());
  window.addEventListener("yt-navigate-finish", () => filterAll());

  // Fallback URL watcher
  let last = location.href;
  setInterval(() => {
    if (location.href !== last) {
      last = location.href;
      filterAll();
    }
  }, 800);
}

function schedule(fn) {
  if (scheduled) return;
  scheduled = true;
  requestAnimationFrame(() => { scheduled = false; fn(); });
}

// ---- Console helpers ----------------------------------------------------
window.__dumpBadgeClasses = () => {
  const set = new Set();
  document.querySelectorAll('#contents ytd-rich-item-renderer ytd-badge-supported-renderer')
    .forEach(el => el.classList.forEach(c => set.add(c)));
  console.log("badge classes:", [...set].sort());
};
window.__dumpBadgeAttrs = () => {
  const vals = new Set();
  document.querySelectorAll('#contents ytd-rich-item-renderer ytd-badge-supported-renderer')
    .forEach(el => {
      for (const a of el.attributes) if (a.value) vals.add(`${a.name}=${a.value}`);
    });
  console.log("badge attrs:", [...vals].slice(0, 200));
};
window.__dumpOverlayStyles = () => {
  const map = {};
  document.querySelectorAll('#contents ytd-rich-item-renderer ytd-thumbnail-overlay-time-status-renderer')
    .forEach(el => {
      const k = el.getAttribute('overlay-style') || 'DEFAULT';
      map[k] = (map[k] || 0) + 1;
    });
  console.log("overlay-style counts:", map);
};

// ---- Optional: quick stats ---------------------------------------------
function logStats(tag) {
  const tiles = getTiles();
  const members = tiles.filter(t => t.getAttribute("data-is-member") === "1").length;
  const non = tiles.length - members;
  console.log(`[members-filter:${tag}] tiles=${tiles.length} members=${members} non=${non} mode=${mode}`);
}
